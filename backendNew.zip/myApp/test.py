import os
import openai
openai.organization = "org-fBoqj45hvJisAEGMR5cvPnDS"
openai.api_key = "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"
openai.Model.list()