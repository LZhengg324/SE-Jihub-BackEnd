

def getUserId(id):
  return id